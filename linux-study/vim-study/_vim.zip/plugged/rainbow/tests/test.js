typoo
(typoo)

console.log({w: 200, h: 100, pos: [{x: 1, y: 2}, {x: 3, y: 4}]})

